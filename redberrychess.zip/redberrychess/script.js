let btn = document.getElementById('landingPageButton');
// var url = window.location.search;
// var url = url.replace(/^.*\/\/[^\/]+/, 'account_registration/index.html')
btn.onclick = () => {
  window.location.href = 'account_registration'
}
