let btn = document.getElementById('nextbtn-chessexperience');

btn.onclick = () => {
  window.location.href = 'chess_experience/index.html'
};
