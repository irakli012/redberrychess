let btn = document.getElementById('nextbtn-completepage');

btn.onclick = () => {
    window.location.href = 'complete_page/index.html'
  };
